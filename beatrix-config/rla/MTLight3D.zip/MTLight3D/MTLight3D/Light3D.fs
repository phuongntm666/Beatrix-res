varying highp vec3 FragPos;
varying highp vec2 TexCoords;
//varying highp vec3 Normals;
varying highp vec2 FaceTexCoords;
// 光源位置
uniform highp vec3 lightPos;
uniform highp vec3 viewPos;

uniform sampler2D diffuseMap;//用户原始图
uniform sampler2D maskMap;//打光区域
uniform sampler2D normalMap;//法向量
uniform sampler2D normalMap_flat;//平滑的法向量

uniform highp float inputAlpha;//柔软度调节系数

// 亮度
uniform highp float lightIntensity;
// 光源距离
uniform highp float lightDistanceZ;
// 环境光参数
uniform highp float lightAmbient;
// 混合图片参数
uniform highp float mixParam;


highp vec3 RGB2YCbCr(highp vec3 originalColor)
{
    
    highp float y = 0.257 * originalColor.r + 0.564 * originalColor.g + 0.098 * originalColor.b;
    highp float Cb = -0.148 * originalColor.r - 0.291* originalColor.g + 0.439* originalColor.b + 128.0/255.0;
    highp float Cr = 0.439 * originalColor.r - 0.368* originalColor.g + 0.071* originalColor.b + 128.0/255.0;
    
    return vec3(y,Cb,Cr);
}


highp vec3 YCbCr2RGB(highp vec3 YCbCr)
{
    highp float y = YCbCr.x;
    highp float Cb = YCbCr.y;
    highp float Cr = YCbCr.z;
    
    highp float r = 1.164*(y - 16.0/255.0) + 1.596*(Cr - 128.0/255.0);
    highp float g = 1.164*(y - 16.0/255.0) - 0.393 * (Cb - 128.0/255.0) - 0.813 *(Cr - 128.0/255.0);
    highp float b = 1.164*(y - 16.0/255.0) + 2.017 * (Cr - 128.0/255.0);
    
    return vec3(r,g,b);
}

void main()
{
    highp vec3 light_diffuse = vec3(lightIntensity);//（0.75 + 0.5 / 3.0） * 0.3 = 0.275;
    highp vec3 light_ambient = vec3(0.75);      //my:亮度
    //highp vec3 light_spacular = vec3(1.0);
    //用户图的颜色
    highp vec3 originalColor = texture2D(diffuseMap,FaceTexCoords).rgb;
    //用户图的灰度
    highp float originalGray = RGB2YCbCr(originalColor).x;
    
    highp vec3 Mask = texture2D(maskMap,TexCoords).rgb;
    //原始的法向量
    highp vec3 maxNormal = texture2D(normalMap, TexCoords).rgb*2.0-1.0;
    //平滑后的法向量
    highp vec3 minNormal = texture2D(normalMap_flat, TexCoords).rgb*2.0-1.0;  //2.0
    //柔软度
    highp float alpha = inputAlpha;
    highp vec3 normal =(maxNormal*alpha + minNormal*(1.0-alpha));
    highp vec3 lightDir = normalize(vec3(lightPos.x,lightPos.y,lightPos.z*(lightDistanceZ*2.0))-FragPos);
    highp float cosvalue = max( dot(normal,lightDir),0.0);
    
    
    //漫反射
    //漫反射系数
    highp float temp = (0.5 - min(originalGray,0.5)) * 2.0;
    highp vec3 diffuse_coefficient = light_diffuse * (pow(temp,3.0)+1.0);
    highp vec3 diffuse = cosvalue * originalColor * diffuse_coefficient;
    
    // 环境光
    highp vec3 ambient = originalColor * light_ambient ;
    highp vec3 resultColor =  ambient+diffuse;
    
    highp float resultGray = RGB2YCbCr(resultColor).x;
    if(resultGray < originalGray)
        resultColor = originalColor;
    
    resultColor = mix(resultColor,originalColor,Mask.r);    //获得结果图
    resultColor = mix(originalColor,resultColor, mixParam); //做原图与结果图之间的混合
    gl_FragColor = vec4(resultColor, 1.0);
}
